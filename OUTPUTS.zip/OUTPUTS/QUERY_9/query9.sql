#What is the base price of various products.Used to plot histogram.
SELECT base_price
FROM fact_events;